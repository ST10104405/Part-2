﻿using ReciepeApp_Part2;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeApp_Part2
{
    class Program
    {
        static List<Recipe> recipes = new List<Recipe>(); // List to store recipes

        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("1. Enter a new recipe");
                Console.WriteLine("2. Display all recipes");
                Console.WriteLine("3. Select a recipe to display");
                Console.WriteLine("4. Exit");
                Console.Write("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        EnterRecipeDetails();
                        break;

                    case 2:
                        DisplayAllRecipes();
                        break;

                    case 3:
                        SelectRecipeToDisplay();
                        break;

                    case 4:
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        static void EnterRecipeDetails()
        {
            Recipe recipe = new Recipe();

            Console.Write("Enter recipe name: ");
            recipe.Name = Console.ReadLine();

            Console.Write("Enter number of ingredients: ");
            int numIngredients = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < numIngredients; i++)
            {
                Ingredient ingredient = new Ingredient();
                Console.Write($"Enter name of ingredient {i + 1}: ");
                ingredient.Name = Console.ReadLine();
                Console.Write($"Enter quantity of ingredient {i + 1}: ");
                ingredient.Quantity = Convert.ToDouble(Console.ReadLine());
                Console.Write($"Enter unit of measurement for ingredient {i + 1}: ");
                ingredient.Unit = Console.ReadLine();
                Console.Write($"Enter number of calories for ingredient {i + 1}: ");
                ingredient.Calories = Convert.ToInt32(Console.ReadLine());
                Console.Write($"Enter food group for ingredient {i + 1}: ");
                ingredient.FoodGroup = Console.ReadLine();

                recipe.Ingredients.Add(ingredient);
            }

            Console.Write("Enter number of steps: ");
            int numSteps = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < numSteps; i++)
            {
                Step step = new Step();
                Console.Write($"Enter description of step {i + 1}: ");
                step.Description = Console.ReadLine();

                recipe.Steps.Add(step);
            }

            recipes.Add(recipe);

            Console.WriteLine("Recipe details entered successfully!");
        }

        static void DisplayAllRecipes()
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes found.");
                return;
            }

            Console.WriteLine("All Recipes:");
            List<Recipe> sortedRecipes = recipes.OrderBy(r => r.Name).ToList();

            foreach (var recipe in sortedRecipes)
            {
                Console.WriteLine(recipe.Name);
            }
        }

        static void SelectRecipeToDisplay()
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes found.");
                return;
            }

            Console.WriteLine("Select a Recipe:");

            for (int i = 0; i < recipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipes[i].Name}");
            }

            Console.Write("Enter the recipe number: ");
            int recipeNumber = Convert.ToInt32(Console.ReadLine());

            if (recipeNumber >= 1 && recipeNumber <= recipes.Count)
            {
                Recipe selectedRecipe = recipes[recipeNumber - 1];
                DisplayRecipe(selectedRecipe);
            }
            else
            {
                Console.WriteLine("Invalid recipe number.");
            }
        }

        static void DisplayRecipe(Recipe recipe)
        {
            Console.WriteLine("Recipe:");
            Console.WriteLine($"Name: {recipe.Name}");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in recipe.Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
                Console.WriteLine($"Calories: {ingredient.Calories}");
                Console.WriteLine($"Food Group: {ingredient.FoodGroup}");
            }
            Console.WriteLine("Steps:");
            for (int i = 0; i < recipe.Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipe.Steps[i].Description}");
            }

            int totalCalories = recipe.Ingredients.Sum(ingredient => ingredient.Calories);
            Console.WriteLine($"Total Calories: {totalCalories}");

            if (totalCalories > 300)
            {
                Console.WriteLine("Warning: Total calories exceed 300!");
            }
        }
    }
}