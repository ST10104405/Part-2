# Recipe Application

The Recipe Application is a command-line tool that allows users to manage and explore recipes. It provides functionality to enter and store recipe details, display recipes, scale recipes, reset quantities, and clear recipes. Additionally, it includes additional features such as tracking ingredient calories, food groups, and notifying users when the total calories of a recipe exceed 300.

## Features

- Enter an unlimited number of recipes
- Assign a name to each recipe
- Display a list of all recipes in alphabetical order by name
- Select a recipe to display its details
- Enter ingredients with quantities, units of measurement, calories, and food groups
- Add and manage steps for each recipe
- Scale recipes based on a scaling factor
- Reset ingredient quantities
- Clear recipe details
- Calculate and display the total calories of a recipe
- Notify users when the total calories of a recipe exceed 300

## Getting Started



1. Link or Navigate to the project directory: https://github.com/ST10104405/Part-2

3. Build the project:

4. Run the application:

Usage

1. Upon running the application, you will be presented with a menu of options.
2. Choose an option by entering the corresponding number and pressing Enter.
3. Follow the prompts to perform various actions such as entering recipe details, displaying recipes, scaling recipes, resetting quantities, and clearing recipes.
4. When entering ingredient details, you can specify the name, quantity, unit of measurement, calories, and food group.
5. To display all recipes, select the "Display all recipes" option.
6. To select and display a specific recipe, choose the "Select a recipe to display" option and follow the instructions.
7. The total calories of each recipe will be calculated and displayed. If the total calories exceed 300, a warning will be shown.

Contributing

Contributions are welcome! If you find any issues or have suggestions for improvements, please open an issue or submit a pull request.







